package book.exceptions;

/**
 * Exception thrown by the ProductService
 * 
 * @author Matthew Swan, Nithyanandh Mahalingam, Duely Yung
 */

public class ProductServiceException extends Exception	{

	ProductServiceException(String msg)	{
		super(msg);
	}
}
